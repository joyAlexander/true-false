//
//  QuestionProvider.swift
//  TrueFalseStarter
//
//  Created by Joy Ferguson on 6/21/17.
//  Copyright © 2017 Treehouse. All rights reserved.
//

import Foundation
import GameKit


// creating a struct to have a blueprint of the values I need for one question : the question, possible answers and correct answer.
struct triviaQuestion {
    let question: String
    let option1: String
    let option2: String
    let option3: String
    let option4: String
    let correctAnswer: String
    
}

// as per the instructions, generating a random number so that questions are asked randomly

let question1 = triviaQuestion(question: "Where did I get Sunday?", option1: "Pennsylvania", option2: "New York", option3: "Los Angeles", option4: "Paris", correctAnswer: "Pennsylvania")
let question2 = triviaQuestion(question: "What colour is Sunday?", option1: "White", option2: "Yellow", option3: "Brown", option4: "Black", correctAnswer: "Yellow")
let question3 = triviaQuestion(question: "How old is Sunday?", option1: "6 month", option2: "1", option3: "2", option4: "3", correctAnswer: "3")
let question4 = triviaQuestion(question: "What is the name of Sunday's friend", option1: "Waffle", option2: "Ginger", option3: "Mildred", option4: "Ghost", correctAnswer: "Mildred")

// putting all the questions in an array that I will use to generate a random number.


var allQuestions: [triviaQuestion] = [question1, question2, question3, question4]

// function for questions to appear randomly

func randomQuestion() -> triviaQuestion {
    let randomInt = GKRandomSource.sharedRandom().nextInt(upperBound: allQuestions.count)
    
    //1. Assign chosen question to new variable. var chosenQ = allQuestions[randomInt]
    let chosenQ = allQuestions[randomInt]
    
    //2. Remove the question at that particular point in the array.
    allQuestions.remove(at: randomInt)
    
//    return allQuestions[3] //New variable name.
    return chosenQ
}



